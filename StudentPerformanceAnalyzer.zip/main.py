def number_sorter(numbers):
    ascending = sorted(numbers)
    descending = sorted(numbers, reverse=True)
    return {"ascending": ascending, "descending": descending}

def sleep_score(hours):
    if hours >= 8:
        print("You're a sleep king 😴👑")
    elif 5 <= hours < 8:
        print("Respectable sleep. Not bad.")
    elif hours < 5:
        print("Go to bed right now, my guy. This ain’t it.😵‍💫")

def sleep_quality(hours, mood):
    if hours >= 8 and mood == "happy":
        print("Sleep game strong. Mental health at 100% ✅")
    elif hours <= 5 and mood == "tried":
        print("Bro... both body and soul need a nap. 💀")
    else:
        print("Sleep schedule is chaotic neutral. Try again tomorrow 😴")

def energy_level(sleep_hours, caffeine_cups):
    if sleep_hours >= 7 and caffeine_cups == 0:
        print("You're a natural energy beast! 🔋🌞")
    elif sleep_hours < 5 and caffeine_cups >= 2: 
        print("You're surviving on bean juice... hang in there ☕😵‍💫")
    elif sleep_hours >= 6 and caffeine_cups >= 1: 
        print("Balanced energy. Nice combo! ⚖️")
    else:
        print("Energy is... questionable. 🙃")

def mood_meter(mood):
    if mood == "happy":
        print("Living my life don't want anyone! ✅")
    elif mood == "sad":
        print("Wish I never existed! 💀")
    elif mood == "angry":
        print("You wanna live or not? Want to show your mom face or not? 😡")
    elif mood == "tired":
        print("Sleep for now! 😴")
    else:
        print("Can't understand you! 😒")

def mood_mixer(name, mood1, mood2):
    if mood1 == "happy" and mood2 == "nappy":
        return f"{name} feels like a {mood1} {mood2} trying to nap."
    else:
        return f"{name} feels like a {mood1} {mood2}."

# Example call
if __name__ == "__main__":
    print(number_sorter([5, 2, 9, 1, 5, 6]))
    sleep_score(6)
    sleep_quality(5, 'tried')
    energy_level(4, 2)
    mood_meter("angry")
    print(mood_mixer("Shoaib", "happy", "nappy"))
