# Student Performance Analyzer
This Python project contains fun and functional methods to assess sleep, mood, energy, and basic number sorting.